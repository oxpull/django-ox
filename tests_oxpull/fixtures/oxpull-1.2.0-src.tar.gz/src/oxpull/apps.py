from django.apps import AppConfig


class OxpullConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "oxpull"
    verbose_name = "Oxpull Pro"
