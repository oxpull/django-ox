"""
The Pro backend. Switching from the free tier is one settings edit, made
in every process that enqueues or claims; a process still on OxBackend
or the free Worker writes no lock row and applies no limit, and nothing
in the database stops it:

    TASKS = {
        "default": {
            "BACKEND": "oxpull.backend.OxpullBackend",
            ...
        }
    }

Workers, schedules, pruning and the table layout are unchanged django-ox;
this module never modifies django-ox state or tables and adds behaviour
strictly at the enqueue seam. One observable difference: the sender class
of the task signals becomes OxpullBackend, so receivers registered with
sender=django_ox.backend.OxBackend must register with sender=None or with
OxpullBackend instead.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from typing import Any, cast

from django.apps import apps
from django.conf import settings
from django.core import checks
from django.core.exceptions import ImproperlyConfigured
from django.db import (
    DatabaseError,
    IntegrityError,
    OperationalError,
    connections,
    transaction,
)
from django.db.models import Exists, OuterRef
from django.tasks.base import Task, TaskResult
from django.tasks.exceptions import InvalidTask
from django.utils import timezone
from django.utils.module_loading import import_string
from django_ox.backend import OxBackend

from .exceptions import UniqueEnqueueRace
from .rate_limits import (
    RateLimit,
    rate_limits_from_options,
    refresh_interval_from_options,
)
from .routing import oxpull_db_alias
from .unique import is_registered, unique_key, unique_tasks_from_options

# Bound on the duplicate-path retry loop. A pass either returns the live
# holder's result, deletes one stale lock generation, or (MySQL only)
# ends as an InnoDB deadlock victim and is reissued, so reaching the
# bound takes that many finished generations or lost deadlocks during a
# single enqueue call.
MAX_UNIQUE_ATTEMPTS = 5

# MySQL's ER_LOCK_DEADLOCK. The insert race here can genuinely deadlock
# under InnoDB: a losing INSERT's duplicate check leaves a shared lock
# on the conflicting index record, and two losers re-inserting after a
# stale lock's DELETE each wait on the other's shared lock. InnoDB
# resolves the cycle by rolling back one victim's entire transaction,
# and its manual's instruction for 1213 is to reissue that transaction.
ER_LOCK_DEADLOCK = 1213

# The three ways a database stops waiting for the holder of a key. The
# lock INSERT on the loser's side blocks on the winner's uncommitted row,
# and the enqueue joins the caller's transaction, so a slow request holds
# the key for as long as it runs. SQLite gives up after the connection's
# busy timeout (OPTIONS["timeout"], 5 s unless set) with SQLITE_BUSY;
# every extended busy code shares that primary code, SQLITE_BUSY_SNAPSHOT
# among them, which a WAL-mode read-to-write upgrade raises at once
# rather than after the timeout. MySQL gives up after
# innodb_lock_wait_timeout (50 s unless set) with ER_LOCK_WAIT_TIMEOUT,
# rolling back the statement and not the transaction. PostgreSQL waits
# for as long as the holder runs unless the project sets lock_timeout,
# which ends the wait with lock_not_available. A statement_timeout ends
# it too, as query_canceled (57014); that one is not specific to this
# contention and propagates raw.
SQLITE_BUSY = 5
# The extended code for the WAL-mode case: a transaction that read before
# it wrote asks to become a writer after another connection committed,
# and SQLite refuses at once rather than waiting out the busy timeout.
SQLITE_BUSY_SNAPSHOT = SQLITE_BUSY | (2 << 8)
ER_LOCK_WAIT_TIMEOUT = 1205
PG_LOCK_NOT_AVAILABLE = "55P03"


def is_innodb_deadlock(exc: OperationalError, db_alias: str) -> bool:
    if connections[db_alias].vendor != "mysql":
        return False
    return bool(exc.args and exc.args[0] == ER_LOCK_DEADLOCK)


def _is_lock_wait_timeout(exc: OperationalError, db_alias: str) -> bool:
    """Whether the database gave up waiting for another transaction's lock."""
    vendor = connections[db_alias].vendor
    cause = exc.__cause__
    if vendor == "sqlite":
        code = getattr(cause, "sqlite_errorcode", None)
        return isinstance(code, int) and code & 0xFF == SQLITE_BUSY
    if vendor == "mysql":
        return bool(exc.args and exc.args[0] == ER_LOCK_WAIT_TIMEOUT)
    if vendor == "postgresql":
        return getattr(cause, "sqlstate", None) == PG_LOCK_NOT_AVAILABLE
    return False


class OxpullBackend(OxBackend):
    """
    OxBackend plus unique tasks.

    A task is unique when marked with @oxpull.unique.unique or listed in
    this backend's OPTIONS["UNIQUE_TASKS"]. Enqueueing a unique task whose
    key is already held by a READY or RUNNING task returns that task's
    TaskResult instead of inserting a second row; task_enqueued is not
    sent for the suppressed duplicate. Non-unique tasks take the parent
    code path untouched. Uniqueness is scoped per backend alias.

    enqueue_many() is the one parent method a unique task cannot use, and
    it says so rather than writing duplicates: its bulk INSERT does not
    reach the deduplicating path at all.

    Correctness rests on the same mechanism django-ox proves in-tree for
    schedule ticks: a unique constraint plus an IntegrityError loser path,
    never check-then-insert. The lock row and the task row are written in
    one transaction, so they commit or roll back together, preserving the
    parent backend's durability guarantee (enqueue participates in the
    caller's transaction).

    The oxpull tables must live on the same database as the django_ox
    tables; the lock INSERT and the task INSERT must share a transaction.
    __init__ enforces it against the active router, and every read on the
    dedup path is pinned to that database, so a read-replica router
    cannot serve a stale liveness answer.
    """

    def __init__(self, alias: str, params: dict[str, Any]) -> None:
        super().__init__(alias, params)
        # A split router silently breaks lock/task atomicity; fail at
        # startup, not at the first lost duplicate.
        self._db_alias: str = oxpull_db_alias()
        # Shape errors raise here, loudly, at startup. check() validates
        # the deeper property (that each path imports to a Task).
        self.unique_task_paths: frozenset[str] = unique_tasks_from_options(self.options)

    def _is_unique(self, task: Task[..., Any]) -> bool:
        path = task.module_path
        return is_registered(path) or path in self.unique_task_paths

    def enqueue[**P, R](
        self, task: Task[P, R], args: list[Any], kwargs: dict[str, Any]
    ) -> TaskResult[P, R]:
        if not self._is_unique(task):
            return super().enqueue(task, args, kwargs)
        return self._enqueue_unique(task, args, kwargs)

    def enqueue_many[**P, R](
        self,
        task: Task[P, R],
        calls: Iterable[tuple[Sequence[Any], Mapping[str, Any]]],
    ) -> list[TaskResult[P, R]]:
        """
        The parent's bulk insert, refused for a unique task.

        django-ox writes an enqueue_many() call as one bulk INSERT and
        never goes through enqueue(), so no uniqueness lock is taken.
        The rows land beside a lock that knows nothing about them, every
        later enqueue() of that key keeps returning the original task as
        though deduplication were working, and the duplicates run. A
        guarantee that fails silently is worse than a call that refuses,
        so this refuses and names the task.

        Deduplicating in bulk is separate work, not a smaller version of
        this: each key needs its lock row and its task row inserted
        together, with the losers resolved against whichever holder is
        live, and that is not one conditional INSERT on all three
        supported databases. Non-unique tasks take the parent path
        untouched, bulk INSERT included.
        """
        if self._is_unique(task):
            raise InvalidTask(
                f"Task {task.module_path!r} is unique, and enqueue_many() "
                "cannot hold its uniqueness lock: the rows go in as one bulk "
                "INSERT that never reaches the deduplicating enqueue path, so "
                "the duplicates would be written and run. Call task.enqueue() "
                "once per call, or stop marking the task unique."
            )
        return super().enqueue_many(task, calls)

    def _enqueue_unique[**P, R](
        self, task: Task[P, R], args: list[Any], kwargs: dict[str, Any]
    ) -> TaskResult[P, R]:
        from .models import OxpullUniqueLock

        # Deliberate double-validation: on the duplicate path
        # super().enqueue() never runs, so this is the only validate_task
        # call the request gets; removing it would make InvalidTask
        # depend on queue state.
        self.validate_task(task)
        key = unique_key(self.alias, task.module_path, task.queue_name, args, kwargs)
        db_alias = self._db_alias

        # A lost deadlock rolls back the victim's entire transaction,
        # not just the statement. When this call owns its transactions,
        # a victimised attempt left nothing behind and is reissued in
        # the loop below. Inside a caller's atomic block the server has
        # discarded the caller's work too, and only the caller can
        # decide to redo that, so the error propagates instead.
        ambient_atomic = connections[db_alias].in_atomic_block

        last_conflict: DatabaseError | None = None
        for _ in range(MAX_UNIQUE_ATTEMPTS):
            conflict: IntegrityError | None = None
            try:
                with transaction.atomic(using=db_alias):
                    try:
                        # The lock INSERT gets its own savepoint so that
                        # only its conflict is caught below; an
                        # IntegrityError out of super().enqueue()
                        # propagates raw instead of being misread as a
                        # duplicate.
                        with transaction.atomic(using=db_alias):
                            lock = OxpullUniqueLock.objects.using(db_alias).create(
                                key=key,
                                task_path=task.module_path,
                                queue_name=task.queue_name,
                                created_at=timezone.now(),
                            )
                    except IntegrityError as exc:
                        # The primary key on key: another enqueue holds
                        # it. A conflicting INSERT blocks until the
                        # holding transaction resolves, within the
                        # database's lock wait: PostgreSQL waits for as
                        # long as the holder runs unless lock_timeout is
                        # set, SQLite for OPTIONS["timeout"] (5 s by
                        # default), MySQL for innodb_lock_wait_timeout
                        # (50 s by default). Inside that wait the
                        # winner has committed by the time IntegrityError
                        # surfaces. Past it the database raises instead,
                        # and the OperationalError handler below names
                        # that condition.
                        conflict = exc
                    else:
                        # Lock first, task second: a losing duplicate
                        # rolls back before super().enqueue() runs, so
                        # no task row is written and no task_enqueued
                        # signal fires for a suppressed duplicate.
                        result = super().enqueue(task, args, kwargs)
                        OxpullUniqueLock.objects.using(db_alias).filter(
                            pk=lock.pk
                        ).update(task_id=result.id)
                        return result
                last_conflict = conflict

                existing = self._existing_result(
                    task, key, db_alias, ambient=ambient_atomic
                )
            except OperationalError as exc:
                if _is_lock_wait_timeout(exc, db_alias):
                    # The holder outlived the wait. Nothing of this
                    # enqueue survived: the transaction rolled back when
                    # this call owns it, the savepoint when it does not,
                    # so the caller's transaction is still usable. No
                    # retry here: another wait inside the caller's
                    # request is what a caller should choose, not have
                    # chosen for it, and UniqueEnqueueRace already means
                    # safe to retry.
                    raise UniqueEnqueueRace(
                        self._lock_wait_message(
                            task, exc, db_alias, ambient_atomic=ambient_atomic
                        )
                    ) from exc
                if ambient_atomic or not is_innodb_deadlock(exc, db_alias):
                    raise
                last_conflict = exc
                continue
            if existing is not None:
                return existing
        raise UniqueEnqueueRace(self._race_message(task, db_alias)) from last_conflict

    def _lock_wait_message(
        self,
        task: Task[..., Any],
        exc: OperationalError,
        db_alias: str,
        *,
        ambient_atomic: bool,
    ) -> str:
        """
        Say what happened, per engine, and what is left to retry.

        Three things vary. SQLite in WAL mode refuses a reader's upgrade
        to writer at once (SQLITE_BUSY_SNAPSHOT) rather than after the
        busy timeout, so that case did not wait for anything. MySQL with
        innodb_rollback_on_timeout=ON rolls the whole transaction back on
        1205, not the statement: Django's savepoint rollback then fails
        and marks the connection for rollback, which is how it is known
        here, and nothing the caller did in that transaction survives.
        Everywhere else inside a caller's transaction the enqueue rolled
        back to its savepoint and the transaction is still usable.
        """
        connection = connections[db_alias]
        snapshot = (
            connection.vendor == "sqlite"
            and getattr(exc.__cause__, "sqlite_errorcode", None) == SQLITE_BUSY_SNAPSHOT
        )
        if snapshot:
            message = (
                f"Could not enqueue unique task {task.module_path!r}: this "
                "transaction had read before it wrote, another connection "
                "committed a write in between, and SQLite in WAL mode refuses "
                "to make a writer of a reader whose snapshot is behind "
                "(SQLITE_BUSY_SNAPSHOT); it did not wait. Nothing was written."
            )
        else:
            message = (
                f"Could not enqueue unique task {task.module_path!r}: another "
                "enqueue of the same key held it for longer than the database's "
                "lock wait, and the database stopped waiting for that transaction "
                "to resolve. Nothing was written; the enqueue is safe to retry "
                "once the holder has committed or rolled back."
            )
        if not ambient_atomic:
            return message
        if connection.needs_rollback:
            return message + (
                " This enqueue ran inside an open transaction, and the server "
                "rolled that whole transaction back (MySQL with "
                "innodb_rollback_on_timeout=ON): nothing done in it survives, "
                "the atomic block rolls back on exit, and the whole transaction "
                "is the thing to retry."
            )
        return message + (
            " This enqueue ran inside an open transaction. The enqueue rolled "
            "back to its savepoint and the transaction is still usable, but "
            "retry the whole transaction rather than the enqueue alone: on "
            "MySQL REPEATABLE READ a retry inside it cannot see the winner "
            "that committed after the transaction's snapshot began."
        )

    def _race_message(self, task: Task[..., Any], db_alias: str) -> str:
        message = (
            f"Could not enqueue or deduplicate unique task "
            f"{task.module_path!r} after {MAX_UNIQUE_ATTEMPTS} attempts."
        )
        connection = connections[db_alias]
        if connection.vendor == "mysql" and connection.in_atomic_block:
            message += (
                " Likely cause: MySQL REPEATABLE READ inside an open "
                "transaction cannot see a winner that committed after "
                "this transaction's snapshot began. Enqueue outside the "
                "transaction, or retry after it commits."
            )
        return message

    def _existing_result[**P, R](
        self, task: Task[P, R], key: str, db_alias: str, *, ambient: bool
    ) -> TaskResult[P, R] | None:
        """
        Resolve a lock conflict: return the live holder's result, or
        release the stale lock and return None so the caller retries.
        `ambient` says whether the caller's transaction is open around
        this call, which is where a plain read can answer from a
        snapshot older than the conflict.

        Staleness is derived purely from the task row. The reaper writes
        LOST with no signal (django_ox worker.reap), the ImportError
        terminal path can skip its signal, and ox_prune deletes rows
        outright. All of them land here as "no longer READY or RUNNING,
        or gone", which is the whole point of deriving instead of
        listening.

        The lock row is read first, its task second, and the release at
        the end is pinned to the (key, task_id) generation inspected, so
        a release only ever removes a generation whose task this call
        saw terminal or absent. The previous shape, a semijoin from the
        task side with a lock re-read when it came back empty, could
        re-read a winner that committed after the empty semijoin and
        release its live lock; a CI postgres run caught it returning two
        winners for one key.

        Every read is pinned to the write database: a router that sends
        reads to a lagged replica must not be able to make a live lock
        look stale.
        """
        if not connections[db_alias].features.has_select_for_update:
            # SQLite: no row locks, so there is nothing for a transaction
            # to hold between the read and the DELETE, and no atomic
            # block is opened here. When this call owns its transactions
            # each statement then runs on its own, which matters because
            # a deferred transaction that reads and then writes fails
            # with "database is locked" the moment two of them race.
            # Inside a caller's atomic() the statements run in that
            # transaction regardless: skipping the block ends nothing,
            # and the read-to-write upgrade it makes is the one
            # SQLITE_BUSY_SNAPSHOT refuses (see _lock_wait_message). In
            # both cases the DELETE at the end carries the holder's
            # status in its own WHERE clause, which is what makes the
            # release atomic against a retry: a statement runs whole
            # against SQLite's single writer.
            return self._resolve_conflict(task, key, db_alias, ambient=ambient)
        with transaction.atomic(using=db_alias):
            return self._resolve_conflict(task, key, db_alias, ambient=ambient)

    def _resolve_conflict[**P, R](
        self, task: Task[P, R], key: str, db_alias: str, *, ambient: bool
    ) -> TaskResult[P, R] | None:
        """
        The body of _existing_result, inside one transaction where the
        database has row locks.

        The read that decides a release and the DELETE share a
        transaction so that the row lock the read takes is still held
        when the DELETE runs. This runs after the enqueue transaction
        has ended, so without the atomic each statement would commit on
        its own and the locking read would be refused.
        """
        from django_ox.models import OxTask
        from django_ox.results import task_result_from_db

        from .models import OxpullUniqueLock

        # The statuses in which a holder keeps its key. The read that
        # decides a release and the DELETE that performs it test the
        # same set.
        pending = (OxTask.Status.READY, OxTask.Status.RUNNING)
        lock = OxpullUniqueLock.objects.using(db_alias).filter(key=key).first()
        if lock is None:
            # Released by a concurrent enqueue, or rolled back with the
            # transaction that inserted it. Nothing to release; retry.
            return None
        # A live holder is read without a lock. There is nothing to
        # release for it, and a row lock taken here inside a caller's
        # transaction (ATOMIC_REQUESTS, any atomic() block) would live
        # until that transaction commits: for as long as the request ran,
        # the holder's worker could not renew its lease or write its
        # outcome and the reaper could not take the row. PostgreSQL waits
        # for the request unless lock_timeout is set; MySQL gives up with
        # 1205 after innodb_lock_wait_timeout.
        holder = self._holder(lock.task_id, db_alias, locking=False)
        live = holder is not None and holder.status in pending
        if live and ambient and self._reads_a_snapshot(db_alias):
            # Inside a caller's transaction on MySQL REPEATABLE READ that
            # plain read answers from the transaction's snapshot, and a
            # holder that finished since the snapshot began still reads
            # as RUNNING: the enqueue would hand back a finished task's
            # result and the new work would never be queued. InnoDB has
            # no current read that takes no lock, and a lock here is the
            # one ruled out above, so the committed status is read on a
            # connection of its own, which sees every commit and holds
            # nothing. Only a holder the snapshot calls live pays for
            # that connection; a holder it calls settled is re-read FOR
            # UPDATE below, a current read on this connection. At READ
            # COMMITTED, Django's default for the backend, the plain
            # read is current and nothing is opened.
            live = self._committed_status(lock.task_id, db_alias) in pending
        if live:
            # Pending window holds. Retries also land here: a failed
            # attempt with attempts remaining goes back to READY, so a
            # retrying task keeps its key; retrying is not duplication.
            # The result is built from the row alone: the caller's Task
            # object may carry different using() overrides, and the row
            # is the truth about the task that actually pends.
            return cast("TaskResult[P, R]", task_result_from_db(holder))
        if holder is not None and connections[db_alias].features.has_select_for_update:
            # The release path, and only here, reads the holder with a
            # locking read: the DELETE below is a current write and the
            # status it acts on must be current too. A plain SELECT under
            # REPEATABLE READ answers from the transaction's snapshot: a
            # caller that had read the holder as FAILED, while an operator
            # retry committed READY in between, would read FAILED again
            # here, delete the live lock and insert a second READY row
            # beside the retried one. FOR UPDATE reads the committed row
            # and waits for a retry still in flight. The row lock is
            # released with the enclosing atomic: at once when this call
            # owns it, at the caller's commit when it does not, and until
            # then a retry of that settled row, a straggler's outcome
            # write onto a LOST row and ox_prune of the row wait behind
            # it. A retry that lands after the release reopens the key
            # beside the new holder, the documented operator bypass.
            holder = self._holder(lock.task_id, db_alias, locking=True)
            if holder is not None and holder.status in pending:
                # A retry committed between the two reads, or, inside a
                # MySQL REPEATABLE READ transaction, since its snapshot.
                # The row is locked now and stays so until the enclosing
                # atomic ends; this is the one case a live holder's row
                # is held, and it is bounded to that race.
                return cast("TaskResult[P, R]", task_result_from_db(holder))
        # Stale or dangling: the task finished, was reaped to LOST, or
        # its row was pruned; a null task_id never survives a committed
        # enqueue. Release exactly the generation inspected; key is the
        # primary key, so (key, task_id) pins the generation and the
        # delete is a no-op if a concurrent enqueue already replaced the
        # lock. The pin covers a replaced generation only: a
        # django_ox.actions.retry moves a FAILED or LOST holder back to
        # READY without touching this lock row, so its (key, task_id) is
        # unchanged. The DELETE therefore carries the holder's status in
        # its own WHERE clause as well, and deletes nothing when the
        # holder is READY or RUNNING by then: on SQLite, where no row
        # lock spans the read and the DELETE, that is the whole of the
        # guard, and the statement is atomic against its single writer.
        OxpullUniqueLock.objects.using(db_alias).filter(
            key=key, task_id=lock.task_id
        ).exclude(
            Exists(
                OxTask.objects.using(db_alias).filter(
                    id=OuterRef("task_id"), status__in=pending
                )
            )
        ).delete()
        return None

    @staticmethod
    def _holder(task_id: Any, db_alias: str, *, locking: bool) -> Any:
        from django_ox.models import OxTask

        if task_id is None:
            return None
        rows = OxTask.objects.using(db_alias).filter(id=task_id)
        if locking:
            rows = rows.select_for_update()
        return rows.first()

    @staticmethod
    def _reads_a_snapshot(db_alias: str) -> bool:
        """
        Whether a plain SELECT on this connection, inside its open
        transaction, answers from a read view older than the statement.

        MySQL at REPEATABLE READ, InnoDB's server default, fixes the read
        view at the transaction's first consistent read; at READ
        COMMITTED, which Django's MySQL backend sets on every connection
        unless OPTIONS["isolation_level"] says otherwise, each statement
        takes a fresh one. The session is asked rather than the setting
        read, because the setting may be None for the server's default
        and a session can change its own level.
        """
        connection = connections[db_alias]
        if connection.vendor != "mysql":
            return False
        with connection.cursor() as cursor:
            cursor.execute("SELECT @@transaction_isolation")
            (level,) = cursor.fetchone()
        return str(level).upper().replace("_", "-") == "REPEATABLE-READ"

    @staticmethod
    def _committed_status(task_id: Any, db_alias: str) -> str | None:
        """
        The holder's committed status, read on a connection of its own.

        A connection opened here is outside the caller's transaction, so
        its one statement sees the latest commit, and a consistent read
        takes no lock. Table and column names come from the model and
        are quoted by the backend; the ORM is not used because it routes
        every query through the connection handler, and this connection
        is deliberately not registered there. It is closed before
        returning. None means the row is gone.
        """
        from django_ox.models import OxTask

        meta = OxTask._meta
        id_field = meta.get_field("id")
        # Concrete fields always carry a column; the stubs say Optional.
        id_column = cast("str", id_field.column)
        status_column = cast("str", meta.get_field("status").column)
        fresh = connections.create_connection(db_alias)
        try:
            quote = fresh.ops.quote_name
            sql = (
                f"SELECT {quote(status_column)} "  # noqa: S608 - model names
                f"FROM {quote(meta.db_table)} "
                f"WHERE {quote(id_column)} = %s"
            )
            with fresh.cursor() as cursor:
                cursor.execute(sql, [id_field.get_db_prep_value(task_id, fresh)])
                row = cursor.fetchone()
        finally:
            fresh.close()
        return None if row is None else str(row[0])

    def check(self, **kwargs: Any) -> list[checks.CheckMessage]:
        if self.alias not in settings.TASKS:
            # The parent's schedule checks index settings.TASKS by alias
            # and would KeyError on a backend constructed outside TASKS;
            # fail with a real message instead. Upstream fix recorded in
            # docs/oss-coupling.md.
            return [
                checks.Error(
                    f"Backend alias {self.alias!r} is not present in settings.TASKS.",
                    hint="check() requires a configured alias; construct "
                    "the backend through the TASKS setting.",
                    id="oxpull.E003",
                )
            ]
        errors = super().check(**kwargs)
        if not apps.is_installed("oxpull"):
            errors.append(
                checks.Error(
                    "oxpull must be in INSTALLED_APPS to use OxpullBackend.",
                    hint="Add 'oxpull' to INSTALLED_APPS and run migrations.",
                    id="oxpull.E001",
                )
            )
        errors.extend(self._check_unique_task_paths())
        errors.extend(self._check_router())
        errors.extend(self._check_unique_schedules())
        errors.extend(self._check_rate_limits())
        errors.extend(self._check_reconcile_schedule())
        return errors

    def _check_reconcile_schedule(self) -> list[checks.CheckMessage]:
        """
        Warn, once, when no django-ox backend schedules the reconciler.

        Batches complete only through oxpull.batches.reconcile on a
        schedule, and nothing else says so before the first batch sits
        SEALED forever. The check reads the same settings create() and
        seal() refuse on, and it is emitted from the first OxpullBackend
        alias in sort order rather than from every alias, so one id
        silences it in a project that uses uniqueness or limits and
        never a batch.

        A Warning rather than an Error, unlike E006: check() runs with no
        database, so whether batches exist is unknowable here, and an
        Error would stop migrate and runserver for every installation
        that never creates a batch. The silent failure an Error would
        guard against is closed by the refusal in create() and seal().
        """
        from .batches import (
            reconcile_schedule_aliases,
            reconcile_schedule_hint,
            task_backend_classes,
        )

        if reconcile_schedule_aliases():
            return []
        first = min(
            (
                alias
                for alias, backend_class in task_backend_classes().items()
                if issubclass(backend_class, OxpullBackend)
            ),
            default=None,
        )
        if first != self.alias:
            return []
        return [
            checks.Warning(
                "No django-ox backend in settings.TASKS schedules "
                "oxpull.batches.reconcile. Batches complete only through "
                "that schedule; create() and seal() refuse until one exists.",
                hint=reconcile_schedule_hint(),
                id="oxpull.W002",
            )
        ]

    def _check_rate_limits(self) -> list[checks.CheckMessage]:
        """
        Validate RATE_LIMITS, then insist on a worker that applies it.

        Limits configured without WORKER_CLASS is the feature's only
        silent failure: everything starts, nothing errors, and no limit
        is ever applied. It is an Error rather than a Warning for that
        reason. The check can see it because RATE_LIMITS is the only
        place a limit is declared, and settings are readable here.
        """
        from django_ox.worker import worker_class

        from .worker import OxpullWorker

        try:
            limits = rate_limits_from_options(self.options, self.alias, self.queues)
            refresh_interval_from_options(self.options)
        except ImproperlyConfigured as exc:
            return [
                checks.Error(
                    str(exc),
                    hint="Fix the OPTIONS entry the message names. "
                    "RATE_LIMITS and RATE_REFRESH_INTERVAL are validated "
                    "here so a bad value cannot reach a running worker.",
                    id="oxpull.E005",
                )
            ]
        if not limits:
            return []
        errors = self._check_limited_task_paths(limits)
        if errors:
            return errors
        try:
            runs = worker_class(self.alias)
        except ImproperlyConfigured as exc:
            return [checks.Error(str(exc), id="oxpull.E006")]
        if not issubclass(runs, OxpullWorker):
            return [
                checks.Error(
                    f"Backend {self.alias!r} configures rate limit(s) "
                    f"{sorted(limits)}, but its worker is "
                    f"{runs.__module__}.{runs.__qualname__}, which does not "
                    "apply them. Every limit would be ignored, silently.",
                    hint="Set OPTIONS['WORKER_CLASS'] to 'oxpull.worker.OxpullWorker'.",
                    id="oxpull.E006",
                )
            ]
        return []

    def _check_limited_task_paths(
        self, limits: dict[str, RateLimit]
    ) -> list[checks.CheckMessage]:
        """
        Every path under a limit's `tasks` must import to a Task.

        A limit matches on the task path stored in the row, so a typo
        covers nothing and throttles nothing, and the queue looks healthy
        while the third party being protected is not. Same reasoning as
        the UNIQUE_TASKS check, and the same failure it prevents.
        """
        errors: list[checks.CheckMessage] = []
        for limit in limits.values():
            for path in sorted(limit.task_paths):
                try:
                    obj = import_string(path)
                except ImportError:
                    obj = None
                if not isinstance(obj, Task):
                    errors.append(
                        checks.Error(
                            f"RATE_LIMITS[{limit.name!r}]['tasks'] entry "
                            f"{path!r} is not a django.tasks Task. The limit "
                            "would cover nothing under that name.",
                            hint="Use the dotted path of a @task-decorated "
                            "function, as it is stored on the task row.",
                            id="oxpull.E005",
                        )
                    )
        return errors

    def _check_unique_task_paths(self) -> list[checks.CheckMessage]:
        """
        Shape errors raise in __init__; this validates the deeper
        property, that every configured path imports to a django.tasks
        Task. A typo here would otherwise just silently never dedup.
        """
        errors: list[checks.CheckMessage] = []
        for path in sorted(self.unique_task_paths):
            try:
                obj = import_string(path)
            except ImportError:
                errors.append(
                    checks.Error(
                        f"UNIQUE_TASKS entry {path!r} does not import.",
                        hint="Use the dotted path of a @task-decorated function.",
                        id="oxpull.E002",
                    )
                )
                continue
            if not isinstance(obj, Task):
                errors.append(
                    checks.Error(
                        f"UNIQUE_TASKS entry {path!r} is not a django.tasks Task.",
                        hint="Point it at the module-level name created "
                        "by the @task decorator.",
                        id="oxpull.E002",
                    )
                )
        return errors

    def _check_router(self) -> list[checks.CheckMessage]:
        try:
            oxpull_db_alias()
        except ImproperlyConfigured as exc:
            return [
                checks.Error(
                    str(exc),
                    hint="Route django_ox and oxpull models to the same database.",
                    id="oxpull.E004",
                )
            ]
        return []

    def _check_unique_schedules(self) -> list[checks.CheckMessage]:
        """
        Warn when a schedule enqueues a unique task: schedules already
        dedup once per tick, and a unique scheduled task coalesces with
        any pending manual enqueue of the same key, so the tick row may
        record against the manual task.
        """
        raw = self.options.get("SCHEDULES", {})
        if not isinstance(raw, dict):
            return []  # shape reported by the parent's schedule checks
        warnings: list[checks.CheckMessage] = []
        for name, config in raw.items():
            path = config.get("task") if isinstance(config, dict) else None
            if isinstance(path, str) and (
                is_registered(path) or path in self.unique_task_paths
            ):
                warnings.append(
                    checks.Warning(
                        f"Schedule {name!r} enqueues unique task {path!r}; "
                        "unique scheduled tasks coalesce with pending "
                        "manual enqueues, and ticks may record against "
                        "the manual task.",
                        hint="Schedules already dedup once per tick; "
                        "@unique on a scheduled task is usually redundant.",
                        id="oxpull.W001",
                    )
                )
        return warnings
