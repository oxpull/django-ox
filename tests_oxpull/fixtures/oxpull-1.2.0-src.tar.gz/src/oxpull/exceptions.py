from django.tasks.exceptions import TaskException


class UniqueEnqueueRace(TaskException):
    """
    A unique enqueue exhausted its retries while racing other enqueuers
    over the same key. Safe to retry; never a silent double-enqueue.
    """


class BatchSealed(TaskException):
    """
    A batch was sealed (or completed) before this call ran: add() after
    seal, or a second seal. Membership is frozen at seal so total_count
    stays true; there is no un-seal.
    """


class BatchMemberExists(TaskException):
    """
    The task returned by enqueue() is already a member of this batch.

    Only reachable through unique tasks: a deduplicated enqueue returns
    the pending task's id, and the (batch, task_id) constraint refuses to
    count one task twice in one batch.
    """
