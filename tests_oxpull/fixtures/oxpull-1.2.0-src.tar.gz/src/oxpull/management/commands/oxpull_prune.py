from typing import Any

from django.core.management.base import BaseCommand, CommandError, CommandParser
from django.db.models import Q, QuerySet
from django_ox.models import OxTask

from oxpull.models import OxpullUniqueLock


class Command(BaseCommand):
    help = (
        "Delete unique-task locks whose task is finished or pruned. "
        "Optional hygiene: stale locks are also released lazily by the "
        "next enqueue of the same key; this command clears locks for keys "
        "that are never enqueued again."
    )

    def add_arguments(self, parser: CommandParser) -> None:
        parser.add_argument(
            "--batch-size",
            type=int,
            default=1000,
            help=(
                "Rows deleted per DELETE statement, bounding statement "
                "size on large tables (default: %(default)s)."
            ),
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Report how many locks would be deleted without deleting any.",
        )

    def handle(self, *args: Any, **options: Any) -> None:
        if options["batch_size"] < 1:
            raise CommandError("--batch-size must be a positive integer.")
        live = OxTask.objects.filter(
            status__in=[OxTask.Status.READY, OxTask.Status.RUNNING]
        ).values("id")
        # The isnull arm is not redundant: SQL's NOT IN treats a NULL
        # task_id as unknown, so without it a NULL row would be kept
        # forever. A committed lock never carries a NULL task_id (enqueue
        # writes it in the same transaction), so the arm only clears
        # defensive residue.
        prunable = OxpullUniqueLock.objects.filter(
            Q(task_id__isnull=True) | ~Q(task_id__in=live)
        )
        if options["dry_run"]:
            self.stdout.write(f"Would delete {prunable.count()} stale unique lock(s).")
            return
        deleted = self._delete_in_batches(prunable, options["batch_size"])
        self.stdout.write(f"Deleted {deleted} stale unique lock(s).")

    def _delete_in_batches(
        self, prunable: QuerySet[OxpullUniqueLock], batch_size: int
    ) -> int:
        # Neither the key nor a task's staleness is monotone. Between
        # the SELECT and the DELETE a concurrent enqueue can release a
        # stale lock and insert a new live generation under the same pk,
        # and django_ox.actions.retry can move a FAILED or LOST row back
        # to READY, making a lock the SELECT read as stale live again.
        # The DELETE therefore goes through prunable, which re-applies
        # the staleness predicate inside the statement, so each batch is
        # re-verified against current rows: a stolen key survives, and so
        # does the lock on a task that was retried.
        # Bounded batches are the same idiom as ox_prune's deletes;
        # deliberately duplicated, see docs/oss-coupling.md.
        deleted = 0
        while True:
            batch = list(prunable.values_list("pk", flat=True)[:batch_size])
            if not batch:
                break
            deleted += prunable.filter(pk__in=batch).delete()[0]
        return deleted
