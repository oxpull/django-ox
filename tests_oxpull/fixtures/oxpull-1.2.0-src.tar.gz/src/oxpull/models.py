import uuid

from django.db import models

from .rate_limits import MAX_LIMIT_NAME_LENGTH


class OxpullUniqueLock(models.Model):
    """
    The uniqueness lock for one pending unique task.

    A row means: a task with this key was enqueued and has not been seen
    to finish. The row is written in the same transaction as the OxTask
    INSERT, so the lock and the task commit or roll back together. key is
    the primary key, so the dedup point is a single unique btree,
    maintained once per winner INSERT and once per release DELETE.

    Lock state is derived from the task row, never from signals: the
    django-ox reaper writes FAILED without emitting task_finished, so any
    release mechanism driven by signals would strand locks exactly when a
    worker dies. Instead, a lock whose task is no longer READY or RUNNING
    (or whose task row was pruned) is stale, and is released by the next
    enqueue of the same key or by the oxpull_prune command.

    task_id is a bare UUID, not a ForeignKey: ox_prune deletes finished
    OxTask rows, and a dangling reference must read as "finished" rather
    than block pruning or cascade the lock away while it is still the
    enqueue-time dedup point.
    """

    # SHA-256 hex digest over (backend_alias, task_path, queue_name,
    # args, kwargs).
    key = models.CharField(max_length=64, primary_key=True)
    task_id = models.UUIDField(null=True, blank=True)

    # Denormalised for operators reading the table; the key alone decides.
    # task_path and queue_name stay readable after the task row is pruned,
    # when task_id already dangles by design.
    task_path = models.CharField(max_length=255)
    queue_name = models.CharField(max_length=128, default="default")

    created_at = models.DateTimeField()

    def __str__(self) -> str:
        return f"{self.task_path} [{self.key[:12]}]"


class OxpullBatch(models.Model):
    """
    A named group of tasks and the callbacks that fire once every member's
    row is settled (SUCCESSFUL, FAILED, LOST or DISCARDED) or gone.

    Status moves OPEN -> SEALED -> COMPLETE and never back. Membership is
    frozen at seal, which is also when total_count is snapshotted; the
    reconciler completes a SEALED batch under a compare-and-set on that
    status, and the CAS rowcount is what gets the callbacks enqueued
    once. They then run like any other task, which is at least once.

    There is no FAILED status. Completion is completion: failed_count
    plus the absent on_success callback is how a bad run reads. Collapsing
    "done" and "how it went" into one enum is the door the signal-counting
    design comes back through.

    Batch state is never accumulated from signals. The django-ox reaper
    writes FAILED through a queryset update and emits nothing, so a batch
    that counted task_finished would hang exactly when a worker dies,
    which is the case batches exist to survive. Every count here is
    derived by querying member task rows.

    Callbacks are stored as a dotted task path plus JSON arguments, not
    as a pickled Task: the row outlives the process that created it, and
    the reconciler that enqueues it is a different worker.
    """

    class Status(models.TextChoices):
        OPEN = "OPEN"
        SEALED = "SEALED"
        COMPLETE = "COMPLETE"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=128)
    status = models.CharField(
        max_length=10, choices=Status.choices, default=Status.OPEN
    )

    # Member count frozen at seal time. NULL while OPEN, where the live
    # member count is the only honest answer; after seal it is also the
    # denominator that keeps totals true once ox_prune deletes member
    # task rows.
    total_count = models.PositiveIntegerField(null=True, blank=True)

    on_complete_path = models.CharField(max_length=255, blank=True, default="")
    on_complete_args = models.JSONField(default=list, blank=True)
    on_complete_kwargs = models.JSONField(default=dict, blank=True)

    on_success_path = models.CharField(max_length=255, blank=True, default="")
    on_success_args = models.JSONField(default=list, blank=True)
    on_success_kwargs = models.JSONField(default=dict, blank=True)

    # Written once, in the completing transaction. NULL means "not
    # determined yet" rather than "no failures", which a default of 0
    # would claim about every open batch.
    failed_count = models.PositiveIntegerField(null=True, blank=True)

    # Bare UUIDs of the enqueued callbacks, for the same reason as
    # OxpullBatchMember.task_id: ox_prune deletes finished task rows.
    callback_task_id = models.UUIDField(null=True, blank=True)
    success_task_id = models.UUIDField(null=True, blank=True)

    created_at = models.DateTimeField()
    sealed_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [
            # The reconciler's sweep: every SEALED batch, oldest first.
            models.Index(
                fields=["status", "created_at"], name="oxpull_batch_sweep_idx"
            ),
        ]

    def __str__(self) -> str:
        return f"{self.name} [{self.status}]"


class OxpullBatchMember(models.Model):
    """
    One task's membership of one batch.

    task_id is a bare UUID, not a ForeignKey: ox_prune deletes finished
    OxTask rows, and a foreign key would either block the prune or
    cascade the membership away. A membership row whose task row is gone
    joins to nothing, which is exactly the wanted reading: pruned means
    finished. total_count keeps the denominator honest when that happens.

    The (batch, task_id) constraint refuses to count one task twice in
    one batch, reachable only through a deduplicated unique enqueue, and
    doubles as the index the completion join reads.
    """

    batch = models.ForeignKey(
        OxpullBatch, on_delete=models.CASCADE, related_name="members"
    )
    task_id = models.UUIDField()
    created_at = models.DateTimeField()

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["batch", "task_id"], name="oxpull_batch_member_uniq"
            ),
        ]

    def __str__(self) -> str:
        return f"{self.batch_id} -> {self.task_id}"


class OxpullRateWindow(models.Model):
    """
    The current window of one named rate limit.

    One row per limit name, forever: the table counts admissions, not
    tasks, so it does not grow with traffic and needs no pruner. Every
    statement against it is keyed on limit_name, one name for a write
    and the worker's configured names with IN for the refresh's select,
    with an optional AND window_id = %s; the primary key answers all of
    them on its own. Identity is the column's collation: a name the
    collation folds onto an existing row is that row, which is why the
    worker asks the database which row a renamed limit owns.

    Capacity is not stored. A limit's N and P live in settings, and a
    column holding them would be a second source of truth with no
    answer to which one wins halfway through a rolling deploy.

    There is no foreign key to anything, matching OxpullUniqueLock and
    OxpullBatchMember: there is nothing to reference.
    """

    # The configured name, whose length rate_limits.py validates against
    # this same constant, so a name that reaches a row always fits it.
    limit_name = models.CharField(max_length=MAX_LIMIT_NAME_LENGTH, primary_key=True)

    # Monotone per row, never reset and never reused. It names one window,
    # and it is the compare-and-set target that makes exactly one worker
    # the one that rolls, the role lease_epoch plays on OxTask.
    window_id = models.BigIntegerField(default=0)

    # When this window opened, on the database clock, always. Nothing but
    # this table writes or reads this column, and it is only ever compared
    # against the database's own clock in the same statement, so there is
    # no other writer for it to agree with.
    window_started_at = models.DateTimeField()

    # Admissions counted in the current window. It may exceed the
    # configured capacity by up to one per additional worker process;
    # that overshoot is the guarantee's slack, and a value above the
    # limit here is expected rather than corrupt.
    used = models.PositiveIntegerField(default=0)

    def __str__(self) -> str:
        return f"{self.limit_name} [{self.used} in window {self.window_id}]"
