"""
The worker that applies rate limits.

    TASKS = {
        "default": {
            "BACKEND": "oxpull.backend.OxpullBackend",
            "OPTIONS": {
                "WORKER_CLASS": "oxpull.worker.OxpullWorker",
                "RATE_LIMITS": {
                    "stripe": {
                        "limit": 100,
                        "per": 60,
                        "tasks": ["myapp.billing.charge"],
                    },
                },
            },
        }
    }

`ox_worker` runs this class once WORKER_CLASS names it; there is no
second management command. The supervisor behind `--processes N` starts
every child as `ox_worker`, so a worker chosen anywhere but settings
would be this one at --processes 1 and the free-tier one in every child
above it, and rate limits would evaporate at exactly the scale that
needs them.

The budget is consulted before the claim, never after it. django-ox folds
`attempts = attempts + 1` and `lease_epoch = lease_epoch + 1` into the
claim UPDATE itself, on all three claim paths, so a design that claimed a
task and then discovered it had no budget would have spent an attempt on
a task that never ran, and the lease epoch is a fencing token that cannot
be decremented. A throttled task is therefore never claimed at all: it
stays READY, holds no lease, and is indistinguishable from any other
queued task.

The pre-claim view is necessarily stale, and that is what bounds the
guarantee rather than a shortcut in it:

For a limit of N admissions per period P, with W ox_worker processes
claiming from the queues that carry the limit's tasks, the number of
task attempts started in any one window is at most N + W - 1 + U. U is
the number of admissions whose count did not land: one for each count
that raised (_count_failed) and one for each count the window rolled
out from under MAX_RATE_ATTEMPTS times (the tail of _count), each
logged as rate_limit_uncounted. Add one for each worker process that
dies between claiming a limited task and recording it. With a single
worker process, no such death and every count landed, the limiter is
exact: at most N per window. A window is one generation of the shared
counter row, opened by a roll and lasting P, not every interval of
length P. Windows are contiguous, so an arbitrary interval of length P
that spans a boundary can carry up to 2(N + W - 1 + U). A count that
cannot be written is logged and the attempt runs; three admissions in a
row that the counter did not record, whether the increment raised or
matched no row, close the limit until a write lands.

The proof rests on refreshing the view after every admission, before the
next limited claim, which is why _record() marks the view dirty and why a
limited claim costs a SELECT as well as an UPDATE.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from datetime import timedelta
from typing import TYPE_CHECKING, Any

from django.core.exceptions import ImproperlyConfigured
from django.db import DatabaseError, IntegrityError, transaction
from django.db.models import F, Q
from django.db.models.functions import Now
from django_ox.models import OxTask
from django_ox.worker import Worker

from .models import OxpullRateWindow
from .rate_limits import rate_limits_from_options, refresh_interval_from_options
from .routing import oxpull_db_alias

if TYPE_CHECKING:
    from .rate_limits import RateLimit

logger = logging.getLogger("oxpull")

# Bound on the increment's retry loop. A pass only fails when the window
# rolled between the refresh and the increment, so reaching the bound
# takes that many rolls inside one claim. Mirrors MAX_UNIQUE_ATTEMPTS.
MAX_RATE_ATTEMPTS = 5

# Unrecorded admissions in a row that close a limit: a count that raised,
# or one that matched no row after every attempt. One is a lost count
# and the task runs: the claim is already committed, and losing a
# count is better than losing the task. A run of them is a counter that
# is not being written at all, and admitting against a counter that never
# advances is not rate limiting, it is a worker at full speed with a
# warning in the log.
MAX_COUNT_FAILURES = 3


@dataclass
class _Seen:
    """One limit's window as this worker last read it."""

    window_id: int
    used: int
    # time.monotonic() at which the window ends, derived from the database
    # clock read in the same statement as the row. Local only in its zero
    # point, so a worker whose clock disagrees with the database's still
    # measures the right number of seconds.
    ends_at: float


class OxpullWorker(Worker):
    """
    django-ox's Worker, plus rate limits.

    An install with no limits configured pays nothing: the claim filter
    hooks return their base values, so the emitted SQL is what django-ox
    emits on its own, and claim_one() delegates without a statement of
    its own.
    """

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._limits: dict[str, RateLimit] = rate_limits_from_options(
            self.backend.options, self.backend.alias, self.backend.queues
        )
        self._rate_alias = oxpull_db_alias()
        self._refresh_interval = refresh_interval_from_options(self.backend.options)
        self._seen: dict[str, _Seen] = {}
        self._blocked_paths: frozenset[str] = frozenset()
        self._blocked_queues: frozenset[str] = frozenset()
        # Limits whose counter could not be written MAX_COUNT_FAILURES
        # times running, and the run length that got them there.
        self._closed: set[str] = set()
        self._count_failures: dict[str, int] = {}
        # Stored spelling -> configured name, for a limit whose window row
        # was written under a spelling the column's collation treats as
        # the same name. Learned by _adopt, once; empty everywhere else.
        self._folded: dict[str, str] = {}
        # The view is stale until the first read, and again after every
        # admission this worker makes. That rule is what bounds the
        # overshoot at one per worker rather than at N per worker.
        self._view_stale = True
        self._refresh_after = 0.0
        # Column names come from the model rather than from SQL text here,
        # so a django-ox migration that renamed one would be a failure to
        # import a field, not a fragment that no longer matches.
        self._path_column = OxTask._meta.get_field("task_path").column
        self._queue_column = OxTask._meta.get_field("queue_name").column

    # -- the claim pass ----------------------------------------------------

    def claim_one(self) -> OxTask | None:
        """
        Refresh the budget, claim, then count the admission.

        The refresh and the increment run outside the claim, because the
        SKIP LOCKED path claims inside a transaction that is holding row
        locks on the task table and neither statement belongs in there.

        The claim is the line between fail-closed and fail-open. A
        database error before it propagates: nothing is spent, and the
        poll loop skips the pass. A database error after it, anywhere in
        the accounting, is logged and the claimed task is returned: the
        attempt is spent and the row is RUNNING, and a task claimed but
        never handed over runs nowhere until the reaper finds it.
        """
        if not self._limits:
            return super().claim_one()
        self._refresh_view()
        db_task = super().claim_one()
        if db_task is not None:
            self._record(db_task)
        return db_task

    def claim_filter_q(self) -> Q | None:
        if not (self._blocked_paths or self._blocked_queues):
            return None
        condition = Q()
        if self._blocked_paths:
            condition &= ~Q(task_path__in=sorted(self._blocked_paths))
        if self._blocked_queues:
            condition &= ~Q(queue_name__in=sorted(self._blocked_queues))
        return condition

    def claim_filter_sql(self) -> tuple[str, dict[str, Any]]:
        """
        The same exclusion for the PostgreSQL claim.

        Each array is one bound parameter however many names it holds, so
        a limit covering hundreds of task paths cannot approach the
        statement's parameter ceiling. Both columns are NOT NULL, so
        `<> ALL` has no three-valued-logic trap.
        """
        conjuncts: list[str] = []
        params: dict[str, Any] = {}
        if self._blocked_paths:
            conjuncts.append(f' AND "{self._path_column}" <> ALL(%(ox_blocked_paths)s)')
            params["ox_blocked_paths"] = sorted(self._blocked_paths)
        if self._blocked_queues:
            conjuncts.append(
                f' AND "{self._queue_column}" <> ALL(%(ox_blocked_queues)s)'
            )
            params["ox_blocked_queues"] = sorted(self._blocked_queues)
        return "".join(conjuncts), params

    # -- the budget --------------------------------------------------------

    def _refresh_view(self) -> None:
        if not self._view_stale and time.monotonic() < self._refresh_after:
            return
        self._read_windows()

    def _read_windows(self) -> None:
        """
        One SELECT over every configured limit, then a roll attempt for
        each window the database's own clock says has expired.
        """
        started = time.monotonic()
        if self._closed:
            self._reopen_what_counts_again()
        rows = self._select()
        missing = [name for name in self._limits if name not in rows]
        if missing:
            for name in missing:
                self._seed(name)
            rows = self._select()
            for name in missing:
                if name not in rows:
                    rows[name] = self._adopt(name)
        seen: dict[str, _Seen] = {}
        blocked: set[str] = set()
        for name, config in self._limits.items():
            row = rows[name]
            db_now = row.db_now
            window_id, used = row.window_id, row.used
            ends_at = row.window_started_at + timedelta(seconds=config.per)
            if ends_at <= db_now and self._roll(name, window_id, config.per):
                # This worker opened the window, so the whole capacity is
                # free. The roll takes no token: it runs before any claim,
                # which is what makes it free to lose.
                window_id, used = window_id + 1, 0
                ends_at = db_now + timedelta(seconds=config.per)
            seen[name] = _Seen(
                window_id=window_id,
                used=used,
                ends_at=started + max(0.0, (ends_at - db_now).total_seconds()),
            )
            if used >= config.limit or name in self._closed:
                blocked.add(name)
        self._seen = seen
        self._blocked_paths = frozenset(
            path for name in blocked for path in self._limits[name].task_paths
        )
        self._blocked_queues = frozenset(
            queue for name in blocked for queue in self._limits[name].queues
        )
        self._view_stale = False
        self._refresh_after = started + self._refresh_interval
        if blocked and len(blocked) == len(self._limits) and not self._closed:
            # Nothing this worker can claim is admissible until the
            # earliest of these windows ends, and a window's end is known
            # exactly. That is the payoff for a window over a bucket,
            # whose exhaustion has no knowable expiry. A limit that is
            # closed is the exception: it reopens when the database takes
            # a write again, which no window's end predicts, so the
            # ordinary cooldown paces the probe instead.
            self._refresh_after = max(
                self._refresh_after, min(seen[name].ends_at for name in blocked)
            )

    def _select(self) -> dict[str, Any]:
        # Now() rides along in the same statement so the window's age is
        # measured entirely on the database's clock. Comparing a stored
        # window against timezone.now() would be wrong under USE_TZ=False,
        # where SQLite writes UTC into a column every other writer fills
        # with naive local time.
        #
        # Keyed by the configured name, which is the stored spelling except
        # for a row _adopt has attributed to a limit spelled differently.
        rows = (
            OxpullRateWindow.objects.using(self._rate_alias)
            .filter(limit_name__in=self._limits)
            .annotate(db_now=Now())
        )
        return {self._folded.get(row.limit_name, row.limit_name): row for row in rows}

    def _seed(self, name: str) -> None:
        """
        Open the first window for a limit no worker has used yet.

        The loser of the race takes the winner's row, the same pattern as
        the uniqueness lock and OxScheduleTick. The savepoint keeps a
        caller's transaction usable after the conflict.
        """
        try:
            with transaction.atomic(using=self._rate_alias):
                OxpullRateWindow.objects.using(self._rate_alias).create(
                    limit_name=name, window_started_at=Now()
                )
        except IntegrityError:
            pass

    def _adopt(self, name: str) -> Any:
        """
        Read the row the database holds for a limit under another spelling.

        _seed found a row in its way and _select did not return one under
        this name, so the column's collation treats some other spelling
        as this name: a limit deployed as "Stripe" and renamed to "stripe"
        on MySQL. Only the database knows what its collation folds, so ask
        it with the same predicate every write to the row uses. From here
        on _select reads that row as this limit, and _roll and _count
        already land on it by the same collation, so the count continues
        across the rename rather than the worker dying on it.
        """
        row = (
            OxpullRateWindow.objects.using(self._rate_alias)
            .filter(limit_name=name)
            .annotate(db_now=Now())
            .first()
        )
        if row is None:
            raise ImproperlyConfigured(
                f"Rate limit {name!r}: the window table refused a row for it "
                "and holds none that matches it."
            )
        # The row another configured limit already owns is not this
        # limit's to adopt. The parser refuses two names that differ only
        # by case, which every case-insensitive collation folds; what
        # else a collation folds (MySQL's utf8mb4_0900_ai_ci makes one
        # name of `Café` and `cafe`) only the database can say, and this
        # is where it says it. Two limits on one row would count each
        # other's admissions and throttle traffic neither was configured
        # for, so the worker refuses here, before its first claim. A
        # single limit renamed to a spelling the collation folds is the
        # case above, and it stays a rename.
        other = self._folded.get(row.limit_name)
        if other is None and row.limit_name in self._limits:
            other = row.limit_name
        if other is not None and other != name:
            raise ImproperlyConfigured(
                f"RATE_LIMITS has {other!r} and {name!r}, and the database "
                f"holds one window row ({row.limit_name!r}) for both: the "
                "column's collation treats the two names as one. Two limits "
                "on one row would share a window and throttle each other. "
                "Rename one."
            )
        self._folded[row.limit_name] = name
        logger.info(
            "Rate limit %r: its window row is stored as %r; the column's "
            "collation treats the two as one name, so that row is the limit's",
            name,
            row.limit_name,
            extra={
                "event": "rate_limit_row_adopted",
                "limit": name,
                "stored_as": row.limit_name,
                "worker_id": self.worker_id,
            },
        )
        return row

    def _roll(self, name: str, window_id: int, period: int) -> bool:
        """
        Open the next window, if this worker is the one that gets to.

        window_id is the compare-and-set: the winner's write moves it, so
        every loser's predicate stops matching and their rowcount is 0.
        The period comparison is evaluated on the database clock on both
        sides, so a worker whose clock is wrong cannot roll a live window.
        """
        return bool(
            OxpullRateWindow.objects.using(self._rate_alias)
            .filter(
                limit_name=name,
                window_id=window_id,
                window_started_at__lte=Now() - timedelta(seconds=period),
            )
            .update(window_id=window_id + 1, used=0, window_started_at=Now())
        )

    def _reopen_what_counts_again(self) -> None:
        """
        Probe each closed limit, and reopen the ones that answer.

        A closed limit admits nothing, so no claim will run another count
        and no count will succeed on its own: the only way to learn that
        the counter can be written again is to write one. The probe is
        the statement that failed with no increment in it, so a limit
        that reopens has proved the exact write it is about to need.
        """
        for name in sorted(self._closed):
            try:
                OxpullRateWindow.objects.using(self._rate_alias).filter(
                    limit_name=name
                ).update(used=F("used"))
            except DatabaseError:
                continue
            self._closed.discard(name)
            self._count_failures.pop(name, None)
            logger.warning(
                "Rate limit %r: its counter takes writes again; admitting again",
                name,
                extra={
                    "event": "rate_limit_reopened",
                    "limit": name,
                    "worker_id": self.worker_id,
                },
            )

    def _record(self, db_task: OxTask) -> None:
        counted = False
        for name, config in self._limits.items():
            if config.covers(db_task.task_path, db_task.queue_name):
                self._count(name, db_task)
                counted = True
        if counted:
            # Refresh before the next limited claim. Drop this and a
            # worker that saw an empty window could admit the whole
            # capacity on its own before looking again, and the bound
            # would degrade from N + W - 1 to N x W.
            self._view_stale = True

    def _count(self, name: str, db_task: OxTask) -> None:
        """
        Count one admission. Unconditional, and never a gate.

        The task is already claimed by the time this runs, so a
        compare-and-set that could refuse would have burned the attempt
        this whole design exists to protect. Two workers taking the last
        token both get it; what stops either taking a second is that both
        read the post-increment count at their next refresh.

        A statement that raises is the one case that does gate, at the
        next refresh rather than here: see _count_failed.
        """
        for _ in range(MAX_RATE_ATTEMPTS):
            seen = self._seen.get(name)
            if seen is None:
                return
            try:
                counted = (
                    OxpullRateWindow.objects.using(self._rate_alias)
                    .filter(limit_name=name, window_id=seen.window_id)
                    .update(used=F("used") + 1)
                )
            except DatabaseError:
                self._count_failed(name, db_task)
                return
            if counted:
                # The admission is on the counter, so any earlier run of
                # unrecorded admissions is over. Only a matched row says
                # so: a statement that ran and matched nothing has
                # recorded no more than one that raised.
                self._count_failures.pop(name, None)
                return
            # The window rolled between the refresh and here, so the
            # increment landed on nothing. Re-read and count against the
            # window that is open now. The re-read is accounting too:
            # the claim is committed, so a database that goes away here
            # costs the count, not the task. Left uncaught, the error
            # would escape claim_one() with the task claimed and
            # unreturned, and the row would sit RUNNING until the reaper
            # took it back, one attempt poorer. ImproperlyConfigured is
            # the re-read finding the limit's row gone and the seed
            # refused (_adopt); before the claim that propagates, here it
            # is the same loss of a count and is logged the same way.
            try:
                self._read_windows()
            except (DatabaseError, ImproperlyConfigured):
                self._count_failed(name, db_task)
                return
        logger.warning(
            "Rate limit %r: window rolled under %d attempts to count task "
            "id=%s; it runs uncounted",
            name,
            MAX_RATE_ATTEMPTS,
            db_task.id,
            extra={
                "event": "rate_limit_uncounted",
                "limit": name,
                "task_id": str(db_task.id),
                "worker_id": self.worker_id,
            },
        )
        # Rolled out is an admission that was not recorded, the same as
        # one whose increment raised, and it counts toward the run.
        self._unrecorded(name)

    def _count_failed(self, name: str, db_task: OxTask) -> None:
        """
        Record one failed count, and close the limit on a run of them.

        A single failure is fail-open on purpose: the claim is committed
        and the attempt is spent, so refusing to run the task would lose
        work to save a counter. A run of MAX_COUNT_FAILURES is a
        different thing. The counter is not advancing, every worker's
        next refresh reads a used that never moves, and the limiter
        admits at full speed for as long as the database stays that way.
        Closing the limit fails the other way: throttled work waits,
        which is what a limit is for.
        """
        logger.warning(
            "Rate limit %r: could not count task id=%s; it runs uncounted",
            name,
            db_task.id,
            exc_info=True,
            extra={
                "event": "rate_limit_uncounted",
                "limit": name,
                "task_id": str(db_task.id),
                "worker_id": self.worker_id,
            },
        )
        self._unrecorded(name)

    def _unrecorded(self, name: str) -> None:
        """
        One more admission under this limit went unrecorded; close the
        limit when that makes MAX_COUNT_FAILURES in a row. The run ends
        only when an increment lands (_count), so it is a run of
        admissions the counter does not know about, whichever way each
        one was lost.
        """
        failures = self._count_failures.get(name, 0) + 1
        self._count_failures[name] = failures
        if failures < MAX_COUNT_FAILURES or name in self._closed:
            return
        # Once, on the transition. Every later claim is excluded before
        # it reaches the count, so there is nothing per-claim to log.
        self._closed.add(name)
        logger.warning(
            "Rate limit %r: %d counts failed in a row; admitting nothing "
            "under it until its counter takes a write again",
            name,
            failures,
            extra={
                "event": "rate_limit_closed",
                "limit": name,
                "failures": failures,
                "worker_id": self.worker_id,
            },
        )
